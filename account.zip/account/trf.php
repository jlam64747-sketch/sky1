<?php
session_start();
include_once ('df/session.php');
require_once 'df/controller.php';
if(!isset($_SESSION['uname'])){
header("Location: login.php");
exit(); 
}

$reg_user = new USER();

$stmt = $reg_user->runQuery("SELECT * FROM account WHERE uname=:uname");
$stmt->execute(array(":uname" => $_SESSION['uname']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);

$bill = $row['billing_code'];


if($bill == '2'){
	header('Location: internationalx.php');
	exit();
 
}
if($bill == '3'){
	header('Location: internationaltrf.php');
	exit();
 
}

if (isset($_POST['rname'])) { 
    $_SESSION['rname'] = $_POST['rname'];
}
if (isset($_POST['rbank'])) { 
    $_SESSION['rbank'] = $_POST['rbank'];
}
if (isset($_POST['racc'])) { 
    $_SESSION['racc'] = $_POST['racc'];
}
if (isset($_POST['remail'])) { 
    $_SESSION['remail'] = $_POST['remail'];
}
if (isset($_POST['rswift'])) { 
    $_SESSION['rswift'] = $_POST['rswift'];
}


if (isset($_POST['badd'])) { 
    $_SESSION['badd'] = $_POST['badd'];
}
if (isset($_POST['iban'])) { 
    $_SESSION['iban'] = $_POST['iban'];
}
 
?> 

 <?php include 'df1.php'; ?>
  <div class="content-w">
        <!--------------------
                  START - Breadcrumbs
                  -------------------->
        <ul class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="dashboard.php">Home</a>
            </li>
            <li class="breadcrumb-item">
                <a href="#">Transfer</a>
            </li>
            <li class="breadcrumb-item">
                <span>International</span>
            </li>
        </ul>
        <!--------------------
        END - Breadcrumbs
        -------------------->
  <div class="content-i">
            <div class="content-box">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="element-wrapper">
                            <h6 class="element-header">
                                Transfer
                            </h6>
                            <div class="element-box">
                                <form  action="trf_process.php" method="post" >
                                    <h5 class="form-header">
                                        International Transfer
                                    </h5>
                                    <div class="form-desc">
                                        Funds will reflect in the Beneficiary Account within 72hours.
                                    </div>
                                    <div class="form-group m-t-30">
                                                                            </div>
                           
                                    

						
						
                                    <div class="form-group">
                                        <label for=""> Account Name</label>
										
                                        <input class="form-control" readonly value="<?php echo $_SESSION['rname']; ?>" type="text" id="acc_name" name="acc_name">
								
						
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for=""> Account Number</label>
												
                                                <input class="form-control"  readonly value="<?php echo $_SESSION['racc']; ?>" type="text" id="acc_no" name="racc_no">
				
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="">Bank Name</label>
										
                                                <input class="form-control"  readonly value="<?php echo $_SESSION['rbank']; ?>" type="text" name="bank_name" id="bank_name">
							
                                            </div>
                                        </div>
                                    </div>
                                    <fieldset>
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="">Bank Address</label>
                                                    <input class="form-control"  readonly value="<?php echo $_SESSION['badd']; ?>"  name="" id="" type="text">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="">Country</label>
                                                    <select class="form-control" id="country">
                                                                                                                    <option value="Afghanistan">Afghanistan</option>
                                                                                                                    <option value="Albania">Albania</option>
                                                                                                                    <option value="Algeria">Algeria</option>
                                                                                                                    <option value="American Samoa">American Samoa</option>
                                                                                                                    <option value="Andorra">Andorra</option>
                                                                                                                    <option value="Angola">Angola</option>
                                                                                                                    <option value="Anguilla">Anguilla</option>
                                                                                                                    <option value="Antarctica">Antarctica</option>
                                                                                                                    <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                                                                                                    <option value="Argentina">Argentina</option>
                                                                                                                    <option value="Armenia">Armenia</option>
                                                                                                                    <option value="Aruba">Aruba</option>
                                                                                                                    <option value="Australia">Australia</option>
                                                                                                                    <option value="Austria">Austria</option>
                                                                                                                    <option value="Azerbaijan">Azerbaijan</option>
                                                                                                                    <option value="Bahamas">Bahamas</option>
                                                                                                                    <option value="Bahrain">Bahrain</option>
                                                                                                                    <option value="Bangladesh">Bangladesh</option>
                                                                                                                    <option value="Barbados">Barbados</option>
                                                                                                                    <option value="Belarus">Belarus</option>
                                                                                                                    <option value="Belgium">Belgium</option>
                                                                                                                    <option value="Belize">Belize</option>
                                                                                                                    <option value="Benin">Benin</option>
                                                                                                                    <option value="Bermuda">Bermuda</option>
                                                                                                                    <option value="Bhutan">Bhutan</option>
                                                                                                                    <option value="Bolivia">Bolivia</option>
                                                                                                                    <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                                                                                                    <option value="Botswana">Botswana</option>
                                                                                                                    <option value="Bouvet Island">Bouvet Island</option>
                                                                                                                    <option value="Brazil">Brazil</option>
                                                                                                                    <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                                                                                                                    <option value="Brunei Darussalam">Brunei Darussalam</option>
                                                                                                                    <option value="Bulgaria">Bulgaria</option>
                                                                                                                    <option value="Burkina Faso">Burkina Faso</option>
                                                                                                                    <option value="Burundi">Burundi</option>
                                                                                                                    <option value="Cambodia">Cambodia</option>
                                                                                                                    <option value="Cameroon">Cameroon</option>
                                                                                                                    <option value="Canada">Canada</option>
                                                                                                                    <option value="Cape Verde">Cape Verde</option>
                                                                                                                    <option value="Cayman Islands">Cayman Islands</option>
                                                                                                                    <option value="Central African Republic">Central African Republic</option>
                                                                                                                    <option value="Chad">Chad</option>
                                                                                                                    <option value="Chile">Chile</option>
                                                                                                                    <option value="China">China</option>
                                                                                                                    <option value="Christmas Island">Christmas Island</option>
                                                                                                                    <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                                                                                                                    <option value="Colombia">Colombia</option>
                                                                                                                    <option value="Comoros">Comoros</option>
                                                                                                                    <option value="Congo">Congo</option>
                                                                                                                    <option value="Cook Islands">Cook Islands</option>
                                                                                                                    <option value="Costa Rica">Costa Rica</option>
                                                                                                                    <option value="Croatia (Hrvatska)">Croatia (Hrvatska)</option>
                                                                                                                    <option value="Cuba">Cuba</option>
                                                                                                                    <option value="Cyprus">Cyprus</option>
                                                                                                                    <option value="Czech Republic">Czech Republic</option>
                                                                                                                    <option value="Denmark">Denmark</option>
                                                                                                                    <option value="Djibouti">Djibouti</option>
                                                                                                                    <option value="Dominica">Dominica</option>
                                                                                                                    <option value="Dominican Republic">Dominican Republic</option>
                                                                                                                    <option value="East Timor">East Timor</option>
                                                                                                                    <option value="Ecuador">Ecuador</option>
                                                                                                                    <option value="Egypt">Egypt</option>
                                                                                                                    <option value="El Salvador">El Salvador</option>
                                                                                                                    <option value="Equatorial Guinea">Equatorial Guinea</option>
                                                                                                                    <option value="Eritrea">Eritrea</option>
                                                                                                                    <option value="Estonia">Estonia</option>
                                                                                                                    <option value="Ethiopia">Ethiopia</option>
                                                                                                                    <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                                                                                                                    <option value="Faroe Islands">Faroe Islands</option>
                                                                                                                    <option value="Fiji">Fiji</option>
                                                                                                                    <option value="Finland">Finland</option>
                                                                                                                    <option value="France">France</option>
                                                                                                                    <option value="France, Metropolitan">France, Metropolitan</option>
                                                                                                                    <option value="French Guiana">French Guiana</option>
                                                                                                                    <option value="French Polynesia">French Polynesia</option>
                                                                                                                    <option value="French Southern Territories">French Southern Territories</option>
                                                                                                                    <option value="Gabon">Gabon</option>
                                                                                                                    <option value="Gambia">Gambia</option>
                                                                                                                    <option value="Georgia">Georgia</option>
                                                                                                                    <option value="Germany">Germany</option>
                                                                                                                    <option value="Ghana">Ghana</option>
                                                                                                                    <option value="Gibraltar">Gibraltar</option>
                                                                                                                    <option value="Guernsey">Guernsey</option>
                                                                                                                    <option value="Greece">Greece</option>
                                                                                                                    <option value="Greenland">Greenland</option>
                                                                                                                    <option value="Grenada">Grenada</option>
                                                                                                                    <option value="Guadeloupe">Guadeloupe</option>
                                                                                                                    <option value="Guam">Guam</option>
                                                                                                                    <option value="Guatemala">Guatemala</option>
                                                                                                                    <option value="Guinea">Guinea</option>
                                                                                                                    <option value="Guinea-Bissau">Guinea-Bissau</option>
                                                                                                                    <option value="Guyana">Guyana</option>
                                                                                                                    <option value="Haiti">Haiti</option>
                                                                                                                    <option value="Heard and Mc Donald Islands">Heard and Mc Donald Islands</option>
                                                                                                                    <option value="Honduras">Honduras</option>
                                                                                                                    <option value="Hong Kong">Hong Kong</option>
                                                                                                                    <option value="Hungary">Hungary</option>
                                                                                                                    <option value="Iceland">Iceland</option>
                                                                                                                    <option value="India">India</option>
                                                                                                                    <option value="Isle of Man">Isle of Man</option>
                                                                                                                    <option value="Indonesia">Indonesia</option>
                                                                                                                    <option value="Iran (Islamic Republic of)">Iran (Islamic Republic of)</option>
                                                                                                                    <option value="Iraq">Iraq</option>
                                                                                                                    <option value="Ireland">Ireland</option>
                                                                                                                    <option value="Israel">Israel</option>
                                                                                                                    <option value="Italy">Italy</option>
                                                                                                                    <option value="Ivory Coast">Ivory Coast</option>
                                                                                                                    <option value="Jersey">Jersey</option>
                                                                                                                    <option value="Jamaica">Jamaica</option>
                                                                                                                    <option value="Japan">Japan</option>
                                                                                                                    <option value="Jordan">Jordan</option>
                                                                                                                    <option value="Kazakhstan">Kazakhstan</option>
                                                                                                                    <option value="Kenya">Kenya</option>
                                                                                                                    <option value="Kiribati">Kiribati</option>
                                                                                                                    <option value="Korea, Democratic People&#039;s Republic of">Korea, Democratic People&#039;s Republic of</option>
                                                                                                                    <option value="Korea, Republic of">Korea, Republic of</option>
                                                                                                                    <option value="Kosovo">Kosovo</option>
                                                                                                                    <option value="Kuwait">Kuwait</option>
                                                                                                                    <option value="Kyrgyzstan">Kyrgyzstan</option>
                                                                                                                    <option value="Lao People&#039;s Democratic Republic">Lao People&#039;s Democratic Republic</option>
                                                                                                                    <option value="Latvia">Latvia</option>
                                                                                                                    <option value="Lebanon">Lebanon</option>
                                                                                                                    <option value="Lesotho">Lesotho</option>
                                                                                                                    <option value="Liberia">Liberia</option>
                                                                                                                    <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                                                                                                                    <option value="Liechtenstein">Liechtenstein</option>
                                                                                                                    <option value="Lithuania">Lithuania</option>
                                                                                                                    <option value="Luxembourg">Luxembourg</option>
                                                                                                                    <option value="Macau">Macau</option>
                                                                                                                    <option value="Macedonia">Macedonia</option>
                                                                                                                    <option value="Madagascar">Madagascar</option>
                                                                                                                    <option value="Malawi">Malawi</option>
                                                                                                                    <option value="Malaysia">Malaysia</option>
                                                                                                                    <option value="Maldives">Maldives</option>
                                                                                                                    <option value="Mali">Mali</option>
                                                                                                                    <option value="Malta">Malta</option>
                                                                                                                    <option value="Marshall Islands">Marshall Islands</option>
                                                                                                                    <option value="Martinique">Martinique</option>
                                                                                                                    <option value="Mauritania">Mauritania</option>
                                                                                                                    <option value="Mauritius">Mauritius</option>
                                                                                                                    <option value="Mayotte">Mayotte</option>
                                                                                                                    <option value="Mexico">Mexico</option>
                                                                                                                    <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                                                                                                                    <option value="Moldova, Republic of">Moldova, Republic of</option>
                                                                                                                    <option value="Monaco">Monaco</option>
                                                                                                                    <option value="Mongolia">Mongolia</option>
                                                                                                                    <option value="Montenegro">Montenegro</option>
                                                                                                                    <option value="Montserrat">Montserrat</option>
                                                                                                                    <option value="Morocco">Morocco</option>
                                                                                                                    <option value="Mozambique">Mozambique</option>
                                                                                                                    <option value="Myanmar">Myanmar</option>
                                                                                                                    <option value="Namibia">Namibia</option>
                                                                                                                    <option value="Nauru">Nauru</option>
                                                                                                                    <option value="Nepal">Nepal</option>
                                                                                                                    <option value="Netherlands">Netherlands</option>
                                                                                                                    <option value="Netherlands Antilles">Netherlands Antilles</option>
                                                                                                                    <option value="New Caledonia">New Caledonia</option>
                                                                                                                    <option value="New Zealand">New Zealand</option>
                                                                                                                    <option value="Nicaragua">Nicaragua</option>
                                                                                                                    <option value="Niger">Niger</option>
                                                                                                                    <option value="Nigeria">Nigeria</option>
                                                                                                                    <option value="Niue">Niue</option>
                                                                                                                    <option value="Norfolk Island">Norfolk Island</option>
                                                                                                                    <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                                                                                                                    <option value="Norway">Norway</option>
                                                                                                                    <option value="Oman">Oman</option>
                                                                                                                    <option value="Pakistan">Pakistan</option>
                                                                                                                    <option value="Palau">Palau</option>
                                                                                                                    <option value="Palestine">Palestine</option>
                                                                                                                    <option value="Panama">Panama</option>
                                                                                                                    <option value="Papua New Guinea">Papua New Guinea</option>
                                                                                                                    <option value="Paraguay">Paraguay</option>
                                                                                                                    <option value="Peru">Peru</option>
                                                                                                                    <option value="Philippines">Philippines</option>
                                                                                                                    <option value="Pitcairn">Pitcairn</option>
                                                                                                                    <option value="Poland">Poland</option>
                                                                                                                    <option value="Portugal">Portugal</option>
                                                                                                                    <option value="Puerto Rico">Puerto Rico</option>
                                                                                                                    <option value="Qatar">Qatar</option>
                                                                                                                    <option value="Reunion">Reunion</option>
                                                                                                                    <option value="Romania">Romania</option>
                                                                                                                    <option value="Russian Federation">Russian Federation</option>
                                                                                                                    <option value="Rwanda">Rwanda</option>
                                                                                                                    <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                                                                                                                    <option value="Saint Lucia">Saint Lucia</option>
                                                                                                                    <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                                                                                                                    <option value="Samoa">Samoa</option>
                                                                                                                    <option value="San Marino">San Marino</option>
                                                                                                                    <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                                                                                                                    <option value="Saudi Arabia">Saudi Arabia</option>
                                                                                                                    <option value="Senegal">Senegal</option>
                                                                                                                    <option value="Serbia">Serbia</option>
                                                                                                                    <option value="Seychelles">Seychelles</option>
                                                                                                                    <option value="Sierra Leone">Sierra Leone</option>
                                                                                                                    <option value="Singapore">Singapore</option>
                                                                                                                    <option value="Slovakia">Slovakia</option>
                                                                                                                    <option value="Slovenia">Slovenia</option>
                                                                                                                    <option value="Solomon Islands">Solomon Islands</option>
                                                                                                                    <option value="Somalia">Somalia</option>
                                                                                                                    <option value="South Africa">South Africa</option>
                                                                                                                    <option value="South Georgia South Sandwich Islands">South Georgia South Sandwich Islands</option>
                                                                                                                    <option value="South Sudan">South Sudan</option>
                                                                                                                    <option value="Spain">Spain</option>
                                                                                                                    <option value="Sri Lanka">Sri Lanka</option>
                                                                                                                    <option value="St. Helena">St. Helena</option>
                                                                                                                    <option value="St. Pierre and Miquelon">St. Pierre and Miquelon</option>
                                                                                                                    <option value="Sudan">Sudan</option>
                                                                                                                    <option value="Suriname">Suriname</option>
                                                                                                                    <option value="Svalbard and Jan Mayen Islands">Svalbard and Jan Mayen Islands</option>
                                                                                                                    <option value="Swaziland">Swaziland</option>
                                                                                                                    <option value="Sweden">Sweden</option>
                                                                                                                    <option value="Switzerland">Switzerland</option>
                                                                                                                    <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                                                                                                                    <option value="Taiwan">Taiwan</option>
                                                                                                                    <option value="Tajikistan">Tajikistan</option>
                                                                                                                    <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                                                                                                                    <option value="Thailand">Thailand</option>
                                                                                                                    <option value="Togo">Togo</option>
                                                                                                                    <option value="Tokelau">Tokelau</option>
                                                                                                                    <option value="Tonga">Tonga</option>
                                                                                                                    <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                                                                                                    <option value="Tunisia">Tunisia</option>
                                                                                                                    <option value="Turkey">Turkey</option>
                                                                                                                    <option value="Turkmenistan">Turkmenistan</option>
                                                                                                                    <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                                                                                                                    <option value="Tuvalu">Tuvalu</option>
                                                                                                                    <option value="Uganda">Uganda</option>
                                                                                                                    <option value="Ukraine">Ukraine</option>
                                                                                                                    <option value="United Arab Emirates">United Arab Emirates</option>
                                                                                                                    <option value="United Kingdom">United Kingdom</option>
                                                                                                                    <option value="United States">United States</option>
                                                                                                                    <option value="United States minor outlying islands">United States minor outlying islands</option>
                                                                                                                    <option value="Uruguay">Uruguay</option>
                                                                                                                    <option value="Uzbekistan">Uzbekistan</option>
                                                                                                                    <option value="Vanuatu">Vanuatu</option>
                                                                                                                    <option value="Vatican City State">Vatican City State</option>
                                                                                                                    <option value="Venezuela">Venezuela</option>
                                                                                                                    <option value="Vietnam">Vietnam</option>
                                                                                                                    <option value="Virgin Islands (British)">Virgin Islands (British)</option>
                                                                                                                    <option value="Virgin Islands (U.S.)">Virgin Islands (U.S.)</option>
                                                                                                                    <option value="Wallis and Futuna Islands">Wallis and Futuna Islands</option>
                                                                                                                    <option value="Western Sahara">Western Sahara</option>
                                                                                                                    <option value="Yemen">Yemen</option>
                                                                                                                    <option value="Zaire">Zaire</option>
                                                                                                                    <option value="Zambia">Zambia</option>
                                                                                                                    <option value="Zimbabwe">Zimbabwe</option>
                                                                                                            </select>
                                                </div>
                                            </div>
                                        </div>
                                    </fieldset>
                                    <fieldset class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for=""> Swift Code</label>
												
                                                    <input class="form-control"  readonly value="<?php echo $_SESSION['rswift']; ?>" name="swift_code" id="swift" type="text">
															    
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="">IBAN Number</label>
                                                    <input class="form-control"  readonly value="<?php echo $_SESSION['iban']; ?>" name="" id="swift" type="text">
															  
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                              <div class="form-group">
                                                    <label for="">Amount</label>
													 <span id="sprytf_amount">
                                                    <input class="form-control" placeholder="Amount" name="amount" id="amount" type="number">
															 <span class="textfieldRequiredMsg">Sending Amount is required.</span>
                    			<span class="textfieldMinCharsMsg">minimum of $10.</span> 
                    		</span>
                                                    
                                                </div>
                                            </div>
                                          
                                           <div class="col-sm-6">
                                              <div class="form-group">
                                                    <label for="">Transfer Type</label>
													         <select class="form-control" id="country">
                                                               <option value="Online Banking">Online Banking</option>
                                                                 <option value="Joint Account">Joint Account</option>
                                                                 <option value="Checking">Checking</option>
                                                                 <option value="Savings Account">Savings Account</option>
                                                </select>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <label for="">Description</label>
                                                <textarea class="form-control" rows="5" id="description" name="remarks"></textarea>
                                            </div>
                                        </div>
                                    </fieldset>
                                    <div class="form-buttons-w">
                                        <button class="btn btn-primary" type="submit"> Transfer </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 
 
 
 
  <?php include 'df2.php'; ?>
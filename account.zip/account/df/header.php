<?php
session_start();

include_once('df/session.php');
require_once 'df/controller.php';

// Function to check the user's status in the database
function getUserStatus($username, $connection) {
    $query = "SELECT status FROM account WHERE uname = ?";
    $stmt = $connection->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($status);
    $stmt->fetch();
    $stmt->close();
    return $status;
}

$reg_user = new USER();

if (isset($_POST['s_id'])) { 
    $_SESSION['s_id'] = $_POST['s_id'];
}

if (isset($_POST['c_id'])) { 
    $_SESSION['c_id'] = $_POST['c_id'];
}

if (isset($_SESSION['uname'])) {
    $username = $_SESSION['uname'];
    $status = getUserStatus($username, $connection);

    // Check if the user's status is Inactive, Locked, or Dormant
    if ($status == 'Inactive' || $status == 'Locked' || $status == 'Dormant') {
        session_unset();     // Unset $_SESSION variable for the run-time
        session_destroy();   // Destroy session data in storage
        // header('Location: login.php');
        echo "<script>window.location.href = 'login.php' </script>";
    }
}
?>
<?php
require_once 'dbconnect.php';

include 'mailer/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;




class USER {

    private $conn;

    public function __construct() {
        $database = new Database();
        $db = $database->dbConnection();
        $this->conn = $db;
    }
    
    function send_mail($email, $message, $subject) {
        require_once "mailer/PHPMailer.php";
        require_once "mailer/SMTP.php";
        require_once "mailer/Exception.php";
        
        $mail = new PHPMailer();
        //SMTP Settings (use default cpanel email account)
        $mail->isSMTP();
        $mail->Host = "mail.theservicesportal.com"; //
        $mail->SMTPAuth = true;
        $mail->Username = "support@theservicesportal.com"; // Default cpanel email account
        $mail->Password = 'Portal2024@@'; // Default cpanel email password
        $mail->Port = 465; // 587
        $mail->SMTPSecure = "ssl"; // tls
    
        //Email Settings
        $mail->isHTML(true);
        $mail->setFrom('support@theservicesportal.com','SkyLark'); // Email address/ Bank bane shown to reciever
        $mail->addAddress($email);
        $mail->AddReplyTo("support@theservicesportal.com", "SkyLark"); // Email address/ Bank bane shown to reciever
        $mail->Subject = $subject;
        $mail->MsgHTML($message);
        $send = $mail->Send();
        return $send;
    }

    public function runQuery($sql) {
        $stmt = $this->conn->prepare($sql);
        return $stmt;
    }

    public function lasdID() {
        $stmt = $this->conn->lastInsertId();
        return $stmt;
    }

    public function create($pishure, $fname, $mname, $lname, $uname, $upass, $phone, $email, $type, $work, $acc_no, $addr, $sex, $dob, $marry, $t_bal, $a_bal) {
        try {
            $upass = md5($upass);
            $stmt = $this->conn->prepare("INSERT INTO account(pishure,fname,mname,lname,uname,upass,phone,email,type,work,acc_no,addr,sex,dob,marry,t_bal,a_bal) 
			                                             VALUES(:pishure, :fname, :mname, :lname, :uname, :upass, :phone, :email, :type, :work, :acc_no, :addr, :sex, :dob, :marry, :t_bal, :a_bal)");
            $stmt->bindparam(":pishure", $pishure);
            $stmt->bindparam(":fname", $fname);
            $stmt->bindparam(":mname", $mname);
            $stmt->bindparam(":lname", $lname);
            $stmt->bindparam(":uname", $uname);
            $stmt->bindparam(":upass", $upass);
            $stmt->bindparam(":phone", $phone);
            $stmt->bindparam(":email", $email);
            $stmt->bindparam(":type", $type);
            $stmt->bindparam(":work", $work);
            $stmt->bindparam(":acc_no", $acc_no);
            $stmt->bindparam(":addr", $addr);
            $stmt->bindparam(":sex", $sex);
            $stmt->bindparam(":dob", $dob);
            $stmt->bindparam(":marry", $marry);
            $stmt->bindparam(":t_bal", $t_bal);
            $stmt->bindparam(":a_bal", $a_bal);
            $stmt->execute();
            return $stmt;
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }

    public function transfer($email, $amount, $acc_no, $acc_name, $bank_name, $swift, $routing, $type, $remarks, $cout, $transtype) {
        try {

            $stmt = $this->conn->prepare("INSERT INTO transfer(email,amount,acc_no,acc_name,bank_name,type,swift,routing,remarks,cout,transtype) 
			                                             VALUES(:email, :amount, :acc_no, :acc_name, :bank_name, :type, :swift, :routing, :remarks, :cout, :transtype)");
            $stmt->bindparam(":email", $email);
            $stmt->bindparam(":amount", $amount);
            $stmt->bindparam(":acc_no", $acc_no);
            $stmt->bindparam(":acc_name", $acc_name);
            $stmt->bindparam(":bank_name", $bank_name);
            $stmt->bindparam(":type", $type);
            $stmt->bindparam(":swift", $swift);
            $stmt->bindparam(":routing", $routing);
            $stmt->bindparam(":remarks", $remarks);
            $stmt->bindparam(":cout", $cout);
            $stmt->bindparam(":transtype", $transtype);
            $stmt->execute();
            return $stmt;
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }

    public function temp($email, $amount, $acc_no, $acc_name, $bank_name, $swift, $routing, $type, $remarks, $cout, $transtype) {
        try {

            $stmt = $this->conn->prepare("INSERT INTO temp_transfer(email,amount,acc_no,acc_name,bank_name,type,swift,routing,remarks,cout,transtype) 
			                                             VALUES(:email, :amount, :acc_no, :acc_name, :bank_name, :type, :swift, :routing, :remarks, :cout, :transtype)");
            $stmt->bindparam(":email", $email);
            $stmt->bindparam(":amount", $amount);
            $stmt->bindparam(":acc_no", $acc_no);
            $stmt->bindparam(":acc_name", $acc_name);
            $stmt->bindparam(":bank_name", $bank_name);
            $stmt->bindparam(":type", $type);
            $stmt->bindparam(":swift", $swift);
            $stmt->bindparam(":routing", $routing);
            $stmt->bindparam(":remarks", $remarks);
            $stmt->bindparam(":cout", $cout);
            $stmt->bindparam(":transtype", $transtype);
            $stmt->execute();
            return $stmt;
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }

    public function ticket($tc, $sender_name, $sub, $msg) {
        try {

            $stmt = $this->conn->prepare("INSERT INTO ticket(tc,sender_name,subject,msg) 
			                                             VALUES(:tc, :sender_name, :subject, :msg)");
            $stmt->bindparam(":tc", $tc);
            $stmt->bindparam(":sender_name", $sender_name);
            $stmt->bindparam(":subject", $sub);
            $stmt->bindparam(":msg", $msg);
            $stmt->execute();
            return $stmt;
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }

    public function message($msg_no, $sender_name, $reci_name, $subject, $msg) {
        try {

            $stmt = $this->conn->prepare("INSERT INTO message(msg_no,sender_name,reci_name,subject,msg) 
			                                             VALUES(:msg_no; :sender_name, :reci_name, :subject, :msg)");

            $stmt->bindparam(":msg_no", $msg_no);
            $stmt->bindparam(":sender_name", $sender_name);
            $stmt->bindparam(":reci_name", $reci_name);
            $stmt->bindparam(":subject", $subject);
            $stmt->bindparam(":msg", $msg);
            $stmt->execute();
            return $stmt;
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }

    public function delaccount($id) {
        try {

            $stmt = $this->conn->prepare("DELETE FROM account WHERE id = :id");

            $stmt->bindparam(":id", $id);

            $stmt->execute();
            return $stmt;
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }

    public function update($email, $phone, $addr) {
        $update = "UPDATE account SET
				email = :email,
				phone = :phone,
				addr = :addr,
				
				WHERE id = :id";
        try {
            $stmt = $this->conn->prepare($update);

            $stmt->bindparam(':email', $_POST['email'], PDO::PARAM_STR);
            $stmt->bindparam(':phone', $_POST['phone'], PDO::PARAM_STR);
            $stmt->bindparam(':addr', $_POST['addr'], PDO::PARAM_STR);

            $stmt->execute();
            return $stmt;
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }

    public function bal($t_bal) {
        $update = "UPDATE account SET
				t_bal = :t_bal,
				
				WHERE id = :id";
        try {
            $stmt = $this->conn->prepare($update);

            $stmt->bindparam(':t_bal', $_POST['t_bal'], PDO::PARAM_STR);

            $stmt->execute();
            return $stmt;
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }

    public function login($uname, $upass) {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM account WHERE uname=:uname");
            $stmt->execute(array(":uname" => $uname));
            $userRow = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($stmt->rowCount() == 1) {
                if ($userRow['upass'] == ($upass)) {
                    $_SESSION['userSession'] = $userRow['uname'];
                    return true;
                } else {
                    // header("Location: login.php?error");
                    echo "<script>window.location.href = 'login.php?error' </script>";
                    // exit;
                }
            } else {
                echo "<script>window.location.href = 'login.php?error' </script>";
                exit;
            }
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }

    public function is_logged_in() {
        if (isset($_SESSION['userSession'])) {
            return true;
        }
    }

    public function redirect($url) {
        header("Location: $url");
    }

    public function logout() {
        session_destroy();
        $_SESSION['userSession'] = false;
    }

     

    

    }
       


?>
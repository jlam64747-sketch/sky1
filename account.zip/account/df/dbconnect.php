<?php



/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password)
INPUT UR SQL DETAILS HERE  */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'gigobnco_sghagass');
define('DB_PASSWORD', 'kf1J%ZlytTCp');
define('DB_NAME', 'gigobnco_sghagass');

$host = "localhost";
$database = "gigobnco_sghagass";
$username = "gigobnco_sghagass";
$password = "kf1J%ZlytTCp";



//ONLINE BANKING DATA SETTINGS
$site_title = 'SkyLark';
$domain = 'https://theservicesportal/skylark';
$site_address = '8810 Erdman Crest
South Savo, Pieksämäki sub-region, Pieksämäki';
$site_country = 'Finland';
$site_phone = '+358-(042)-394-7756';
$site_email = 'support@amatechict.com'; 
$live_chat_id = ''; 


//THEME COLOR SETTINGS
$tab = '#0000FF'; 
$font = 'white';
 


$page_loader = '#0000FF';


//PAYMENT SETTINGS
$btc = 'contact support';

$wu = 'Contact Customer Service';
$mg = 'Contact Customer Service';

$bank_name = '';
$bank_addr = '';
$acc = ''; 
$accname = ''; 
$site_swift = 'TSOB827282'; 
$rout = ''; 




class Database
{
   /* Do not set or touch any thing here */  
    private $host = "DB_SERVER";
    private $db_name = "DB_NAME";
    private $username = "DB_USERNAME";
    private $password = "DB_PASSWORD";
    public $conn;
     
    public function dbConnection()
	{
     
	    $this->conn = null;    
        try
		{
            $this->conn = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_NAME, DB_USERNAME, DB_PASSWORD);
			$this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	
        }
		catch(PDOException $exception)
		{
            echo "Connection error: " . $exception->getMessage();
        }
         
        return $this->conn;
    }
}
/* Attempt to connect to MySQL database */
$connection = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($connection === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}



?>
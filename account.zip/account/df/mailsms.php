 <?php 
 
include 'mailer/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;

require_once "mailer/PHPMailer.php";
require_once "mailer/SMTP.php";
require_once "mailer/Exception.php";


     function send_mail($email, $message, $subject) {
        $mail = new PHPMailer();
        //SMTP Settings (use default cpanel email account)
        $mail->isSMTP();
        $mail->Host = "mail.theservicesportal.com"; //
        $mail->SMTPAuth = true;
        $mail->Username = "support@theservicesportal.com"; // Default cpanel email account
        $mail->Password = 'Portal2024@@'; // Default cpanel email password
        $mail->Port = 465; // 587
        $mail->SMTPSecure = "ssl"; // tls
    
        //Email Settings
        $mail->isHTML(true);
        $mail->setFrom('support@theservicesportal.com','SkyLark'); // Email address/ Bank bane shown to reciever
        $mail->addAddress($email);
        $mail->AddReplyTo("support@theservicesportal.com", "SkyLark"); // Email address/ Bank bane shown to reciever
        $mail->Subject = $subject;
        $mail->MsgHTML($message);
        $send = $mail->Send();
        return $send;
    }

    function otp($to, $msg) {
        //twillio
        $sid = "AC99a2326a0790b30a46f2109c01f9b39e"; // Your Account SID from www.twilio.com/console
        $token = "3430c6b577d3ddf268d2600098d96560"; // Your Auth Token from www.twilio.com/console
        $client = new Twilio\Rest\Client($sid, $token);
         try { $message = $client->messages->create(
                '+' . $to, array(
            'from' => 'MY ONLINEBANKING', // From a valid Twilio number
            'body' => $msg
                )
        );
  // Display a confirmation message on the screen
        echo "Sent message to $name";

   //sent successfully
    echo "sent to $to successfully<br>";
  }catch(Exception $e){
    echo $e->getCode() . ' : ' . $e->getMessage()."<br>";
  }

}

    ?>